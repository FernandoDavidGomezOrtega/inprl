<?php

define ('base_url', 'http://localhost/inprl/');
define ('controller_default', 'landingController');
define ('action_default', 'index');
